# NEXORA — Windows desktop client shell 1.0

WPF desktop shell targeting .NET Framework 4.8. Includes a local profile store, notification center, theme controls, page motion, and a subscription/configuration importer.

## Compatibility target
- Windows 7 SP1 (requires applicable updates and .NET Framework 4.8)
- Windows 10 and Windows 11 desktop editions
- WPF / .NET Framework 4.8; Any CPU, x86, and x64 build configurations can be selected in Visual Studio

## Build
1. Install Visual Studio with the **.NET desktop development** workload.
2. Install the .NET Framework 4.8 Developer Pack / targeting pack.
3. Open `NEXORA.sln`.
4. Select Release and the desired platform, then Build Solution.

## Animations 1.0
- Page fade and slide transitions
- Minimal, Smooth, and Dynamic presets
- Adjustable transition duration and intensity
- Per-effect fade/slide toggles
- Reduced-motion switch
- Animated button hover feedback

## Subscription Manager
- Import from HTTP/HTTPS subscription URLs and local files
- URL refresh replaces that source's imported entries
- Local source and node persistence in `%LOCALAPPDATA%\\NEXORA`
- Remove a subscription and its imported nodes
- Recognizes VLESS, VMess, Trojan, Shadowsocks, Hysteria/Hysteria2 links
- Recognizes WireGuard and AmneziaWG-style INI configs, and OpenVPN configs
- Accepts common base64-encoded link lists
- Import size limited to 2 MB; network request timeout 12 seconds
- Import is metadata/config parsing only: it never runs downloaded files, installs drivers, or changes routes

## Important: connection backend is not included
The included demo connection engine remains a placeholder. NEXORA does not create a VPN tunnel and does not claim to be connected. A compatible, separately integrated backend is required for actual connections. Protocol recognition/import does not mean that every protocol has a working tunnel implementation.

## Security and privacy
Imported configuration text can contain passwords, tokens, and private keys. It is stored locally in the current Windows user's LocalAppData folder; protect your Windows account and do not import subscription URLs from sources you do not trust. URL imports make an HTTP/HTTPS request only when you explicitly press **Add URL** or **Update**. NEXORA does not auto-run or install imported content.

## Notes
Windows 7 support requires Windows 7 SP1, servicing updates, and .NET Framework 4.8. Modern Windows blur/backdrop APIs are not used; the glass-like appearance is rendered by WPF.
