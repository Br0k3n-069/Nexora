using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using NEXORA.Models;

namespace NEXORA.Services
{
    // Imports configuration metadata only. It never launches executables or installs drivers.
    public sealed class SubscriptionParser
    {
        private const int MaxBytes = 2 * 1024 * 1024;
        public string Fetch(string url)
        {
            Uri uri; if (!Uri.TryCreate(url, UriKind.Absolute, out uri) || (uri.Scheme != "https" && uri.Scheme != "http")) throw new InvalidDataException("Subscription URL must use HTTP or HTTPS.");
            var req = (HttpWebRequest)WebRequest.Create(uri); req.Method = "GET"; req.Timeout = 12000; req.ReadWriteTimeout = 12000; req.UserAgent = "NEXORA/1.0"; req.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
            using (var res = (HttpWebResponse)req.GetResponse())
            using (var stream = res.GetResponseStream())
            using (var memory = new MemoryStream())
            {
                byte[] buffer = new byte[8192]; int read; while ((read = stream.Read(buffer, 0, buffer.Length)) > 0) { if (memory.Length + read > MaxBytes) throw new InvalidDataException("Subscription exceeds the 2 MB import limit."); memory.Write(buffer, 0, read); }
                return Encoding.UTF8.GetString(memory.ToArray()).Trim();
            }
        }
        public List<ServerNode> Parse(string text, string sourceId)
        {
            if (string.IsNullOrWhiteSpace(text)) throw new InvalidDataException("The imported source is empty.");
            if (text.Length > MaxBytes) throw new InvalidDataException("Import exceeds the 2 MB limit.");
            var lines = text.Replace("\r", "").Split('\n').Select(x => x.Trim()).Where(x => x.Length > 0 && !x.StartsWith("#")).ToList();
            string decoded = TryBase64(text.Trim());
            if (!string.IsNullOrEmpty(decoded) && decoded.IndexOf("://", StringComparison.Ordinal) >= 0) lines = decoded.Replace("\r", "").Split('\n').Select(x => x.Trim()).Where(x => x.Length > 0 && !x.StartsWith("#")).ToList();
            var result = new List<ServerNode>();
            foreach (string line in lines)
            {
                ServerNode node = ParseUri(line, sourceId);
                if (node != null) result.Add(node);
            }
            if (result.Count == 0 && (text.IndexOf("[Interface]", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("client", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("<openvpn", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("remote ", StringComparison.OrdinalIgnoreCase) >= 0))
                result.Add(ParseFileConfig(text, sourceId));
            if (result.Count == 0) throw new InvalidDataException("No supported entries found. Supported links: VLESS, VMess, Trojan, Shadowsocks, Hysteria; files: WireGuard, AmneziaWG, OpenVPN.");
            return result;
        }
        private ServerNode ParseUri(string value, string sourceId)
        {
            string scheme = value.Split(':')[0].ToLowerInvariant();
            string protocol = scheme == "amnezia" || scheme == "amneziawg" ? "AmneziaWG (amnesia)" : scheme == "vless" ? "VLESS" : scheme == "vmess" ? "VMess" : scheme == "trojan" ? "Trojan" : (scheme == "ss" || scheme == "shadowsocks") ? "Shadowsocks" : (scheme == "hysteria" || scheme == "hysteria2" || scheme == "hy2") ? "Hysteria" : null;
            if (protocol == null) return null;
            try
            {
                string candidate = value;
                if (scheme == "vmess" && !value.Contains("@")) { string payload = value.Substring(value.IndexOf(':') + 1); string json = TryBase64(payload); if (json != null) { var m = Regex.Match(json, "\\\"(add|host)\\\"\\s*:\\s*\\\"([^\\\"]+)\\\""); var p = Regex.Match(json, "\\\"port\\\"\\s*:\\s*\\\"?(\\d+)"); var n = Regex.Match(json, "\\\"ps\\\"\\s*:\\s*\\\"([^\\\"]*)\\\""); return new ServerNode { Id = Guid.NewGuid().ToString("N"), Name = n.Success ? n.Groups[1].Value : "VMess node", Protocol = protocol, Host = m.Success ? m.Groups[2].Value : "Unknown", Port = p.Success ? int.Parse(p.Groups[1].Value) : 0, SourceId = sourceId, RawConfiguration = value, ImportedAt = DateTime.Now }; } }
                Uri uri; if (!Uri.TryCreate(candidate, UriKind.Absolute, out uri)) return null;
                return new ServerNode { Id = Guid.NewGuid().ToString("N"), Name = string.IsNullOrEmpty(uri.Fragment) ? protocol + " · " + uri.Host : Uri.UnescapeDataString(uri.Fragment.TrimStart('#')), Protocol = protocol, Host = uri.Host, Port = uri.IsDefaultPort ? 0 : uri.Port, SourceId = sourceId, RawConfiguration = value, ImportedAt = DateTime.Now };
            }
            catch { return null; }
        }
        private ServerNode ParseFileConfig(string text, string sourceId)
        {
            bool wg = text.IndexOf("[Interface]", StringComparison.OrdinalIgnoreCase) >= 0;
            bool am = wg && (text.IndexOf("Jc =", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("Jmin =", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("H1 =", StringComparison.OrdinalIgnoreCase) >= 0);
            Match host = Regex.Match(text, "(?im)^\\s*(?:Endpoint|remote)\\s+([^\\s:#]+)(?::(\\d+))?");
            string proto = wg ? (am ? "AmneziaWG (amnesia)" : "WireGuard") : "OpenVPN";
            return new ServerNode { Id = Guid.NewGuid().ToString("N"), Name = PathName(text, proto), Protocol = proto, Host = host.Success ? host.Groups[1].Value : "Config file", Port = host.Groups[2].Success ? int.Parse(host.Groups[2].Value) : 0, SourceId = sourceId, RawConfiguration = text, ImportedAt = DateTime.Now };
        }
        private string PathName(string text, string fallback) { Match m = Regex.Match(text, "(?im)^\\s*#\\s*name\\s*[:=]\\s*(.+)$"); return m.Success ? m.Groups[1].Value.Trim() : fallback + " configuration"; }
        private string TryBase64(string value)
        {
            try { string s = Regex.Replace(value, "\\s+", ""); s = s.Replace('-', '+').Replace('_', '/'); while (s.Length % 4 != 0) s += "="; return Encoding.UTF8.GetString(Convert.FromBase64String(s)); } catch { return null; }
        }
    }
}
