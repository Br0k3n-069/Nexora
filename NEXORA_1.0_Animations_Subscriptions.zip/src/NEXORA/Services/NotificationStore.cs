using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using NEXORA.Models;

namespace NEXORA.Services
{
    public sealed class NotificationStore
    {
        private readonly string _filePath;

        public NotificationStore()
        {
            string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NEXORA");
            Directory.CreateDirectory(folder);
            _filePath = Path.Combine(folder, "notifications.json");
        }

        public ObservableCollection<NotificationItem> Load()
        {
            try
            {
                if (!File.Exists(_filePath)) return new ObservableCollection<NotificationItem>();
                using (var stream = File.OpenRead(_filePath))
                {
                    var serializer = new DataContractJsonSerializer(typeof(NotificationItem[]));
                    var items = (NotificationItem[])serializer.ReadObject(stream);
                    return new ObservableCollection<NotificationItem>((items ?? new NotificationItem[0]).OrderByDescending(x => x.CreatedAt));
                }
            }
            catch { return new ObservableCollection<NotificationItem>(); }
        }

        public void Save(ObservableCollection<NotificationItem> items)
        {
            var serializer = new DataContractJsonSerializer(typeof(NotificationItem[]));
            string temp = _filePath + ".tmp";
            using (var stream = File.Create(temp)) serializer.WriteObject(stream, items.ToArray());
            if (File.Exists(_filePath)) File.Delete(_filePath);
            File.Move(temp, _filePath);
        }
    }
}
