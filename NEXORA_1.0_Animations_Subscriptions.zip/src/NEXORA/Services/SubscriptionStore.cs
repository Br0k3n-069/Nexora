using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using NEXORA.Models;

namespace NEXORA.Services
{
    public sealed class SubscriptionStore
    {
        private readonly string _folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NEXORA");
        private string SubPath { get { return Path.Combine(_folder, "subscriptions.json"); } }
        private string NodePath { get { return Path.Combine(_folder, "nodes.json"); } }
        public ObservableCollection<SubscriptionItem> LoadSubscriptions() { return Load<SubscriptionItem>(SubPath); }
        public ObservableCollection<ServerNode> LoadNodes() { return Load<ServerNode>(NodePath); }
        private ObservableCollection<T> Load<T>(string path) where T : class
        {
            try { if (!File.Exists(path)) return new ObservableCollection<T>(); using (var s = File.OpenRead(path)) { var ser = new DataContractJsonSerializer(typeof(T[])); return new ObservableCollection<T>(((T[])ser.ReadObject(s) ?? new T[0])); } }
            catch { return new ObservableCollection<T>(); }
        }
        public void Save(ObservableCollection<SubscriptionItem> items) { Save<SubscriptionItem>(SubPath, items); }
        public void SaveNodes(ObservableCollection<ServerNode> items) { Save<ServerNode>(NodePath, items); }
        private void Save<T>(string path, ObservableCollection<T> items)
        {
            Directory.CreateDirectory(_folder); string tmp = path + ".tmp";
            using (var s = File.Create(tmp)) new DataContractJsonSerializer(typeof(T[])).WriteObject(s, items.ToArray());
            if (File.Exists(path)) File.Delete(path); File.Move(tmp, path);
        }
    }
}
