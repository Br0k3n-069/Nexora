using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Net;
using System.Windows.Media.Animation;
using Microsoft.Win32;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using NEXORA.Models;
using NEXORA.Services;

namespace NEXORA
{
    public partial class MainWindow : Window
    {
        private readonly ProfileStore _profileStore = new ProfileStore();
        private readonly NotificationStore _notificationStore = new NotificationStore();
        private readonly DemoConnectionEngine _connectionEngine = new DemoConnectionEngine();
        private readonly SubscriptionStore _subscriptionStore = new SubscriptionStore();
        private readonly SubscriptionParser _subscriptionParser = new SubscriptionParser();
        private readonly System.Collections.ObjectModel.ObservableCollection<SubscriptionItem> _subscriptions;
        private readonly System.Collections.ObjectModel.ObservableCollection<ServerNode> _nodes;
        private readonly System.Collections.ObjectModel.ObservableCollection<Profile> _profiles;
        private readonly System.Collections.ObjectModel.ObservableCollection<NotificationItem> _notifications;

        private readonly Dictionary<string, FrameworkElement> _pages;

        public MainWindow()
        {
            InitializeComponent();

            _profiles = _profileStore.Load();
            ProfilesList.ItemsSource = _profiles;
            _notifications = _notificationStore.Load();
            _subscriptions = _subscriptionStore.LoadSubscriptions();
            _nodes = _subscriptionStore.LoadNodes();
            SubscriptionsList.ItemsSource = _subscriptions;
            NodesList.ItemsSource = _nodes;
            NotificationsList.ItemsSource = _notifications;
            AddNotification("NEXORA is ready", "Workspace started. Your local profiles and preferences are available.", "System");
            UpdateNotificationHeader();

            _pages = new Dictionary<string, FrameworkElement>
            {
                { "Dashboard", DashboardPage },
                { "Connections", ConnectionsPage },
                { "Subscriptions", SubscriptionsPage },
                { "Profiles", ProfilesPage },
                { "Theme", ThemePage },
                { "Layout", LayoutPage },
                { "Animations", AnimationsPage },
                { "Notifications", NotificationsPage },
                { "Settings", SettingsPage }
            };

            var os = Environment.OSVersion;
            var label = "Windows " + os.Version.Major + "." + os.Version.Minor;
            OsBadge.Text = label + " • " + (Environment.Is64BitOperatingSystem ? "x64" : "x86");
            CompatibilityText.Text = label + ". The app targets .NET Framework 4.8 / WPF. Windows 7 requires SP1 and .NET Framework 4.8 installed.";
        }

        private void Navigate_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button == null) return;
            Navigate(button.Tag as string);
        }

        private void Navigate(string key)
        {
            foreach (var page in _pages.Values) page.Visibility = Visibility.Collapsed;
            FrameworkElement selected;
            if (!_pages.TryGetValue(key, out selected)) return;
            selected.Visibility = Visibility.Visible;
            PlayPageTransition(selected);

            var titles = new Dictionary<string, string>
            {
                { "Dashboard", "Dashboard" }, { "Connections", "Connections" },
                { "Profiles", "Profiles" }, { "Subscriptions", "Subscriptions" }, { "Theme", "Theme Studio" },
                { "Layout", "Layout Editor" }, { "Animations", "Animations" },
                { "Notifications", "Notifications" }, { "Settings", "Settings" }
            };
            PageTitle.Text = titles[key];
            PageSubtitle.Text = key == "Dashboard" ? "Your workspace at a glance" : "NEXORA workspace";
        }

        private void PlayPageTransition(FrameworkElement page)
        {
            if (AnimationsEnabled == null || !AnimationsEnabled.IsChecked.GetValueOrDefault() || (ReducedMotion != null && ReducedMotion.IsChecked.GetValueOrDefault())) return;
            double duration = AnimationDuration == null ? 240 : AnimationDuration.Value;
            double intensity = AnimationIntensity == null ? 45 : AnimationIntensity.Value;
            if (AnimationPreset != null && AnimationPreset.SelectedIndex == 0) duration = Math.Min(duration, 140);
            if (AnimationPreset != null && AnimationPreset.SelectedIndex == 2) duration = Math.Max(duration, 360);
            var time = TimeSpan.FromMilliseconds(duration);
            if (PageFadeEnabled == null || PageFadeEnabled.IsChecked.GetValueOrDefault())
            {
                page.Opacity = 0;
                page.BeginAnimation(OpacityProperty, new DoubleAnimation(0, 1, new Duration(time)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
            }
            if (PageSlideEnabled != null && PageSlideEnabled.IsChecked.GetValueOrDefault() && intensity > 0)
            {
                var transform = new TranslateTransform(0, 7 + 15 * intensity / 100.0);
                page.RenderTransform = transform;
                var animation = new DoubleAnimation(transform.Y, 0, new Duration(time)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } };
                transform.BeginAnimation(TranslateTransform.YProperty, animation);
            }
        }

        private void AnimationSettings_Changed(object sender, RoutedEventArgs e)
        {
            if (AnimationDurationText != null && AnimationDuration != null) AnimationDurationText.Text = ((int)AnimationDuration.Value) + " ms";
        }
        private void AnimationSettings_Changed(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (AnimationDurationText != null && AnimationDuration != null) AnimationDurationText.Text = ((int)AnimationDuration.Value) + " ms";
        }
        private void AnimationPreset_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (AnimationDuration == null || AnimationIntensity == null) return;
            if (AnimationPreset.SelectedIndex == 0) { AnimationDuration.Value = 140; AnimationIntensity.Value = 20; }
            else if (AnimationPreset.SelectedIndex == 1) { AnimationDuration.Value = 240; AnimationIntensity.Value = 45; }
            else if (AnimationPreset.SelectedIndex == 2) { AnimationDuration.Value = 420; AnimationIntensity.Value = 75; }
        }

        private void AddSubscriptionUrl_Click(object sender, RoutedEventArgs e)
        {
            string url = SubscriptionUrl.Text.Trim();
            try
            {
                SubscriptionStatus.Text = "Downloading subscription…";
                string content = _subscriptionParser.Fetch(url);
                string id = Guid.NewGuid().ToString("N");
                var parsed = _subscriptionParser.Parse(content, id);
                var item = new SubscriptionItem { Id = id, Name = Uri.UnescapeDataString(new Uri(url).Host), Source = url, ImportType = "URL", AddedAt = DateTime.Now, LastUpdated = DateTime.Now, NodeCount = parsed.Count };
                _subscriptions.Add(item); foreach (var node in parsed) _nodes.Add(node);
                SaveSubscriptions(); SubscriptionUrl.Clear(); SubscriptionsList.SelectedItem = item;
                SubscriptionStatus.Text = "Imported " + parsed.Count + " entries from URL.";
                AddNotification("Subscription imported", item.Name + " · " + parsed.Count + " nodes", "Subscriptions");
            }
            catch (Exception ex) { SubscriptionStatus.Text = "Import failed: " + ex.Message; MessageBox.Show(this, ex.Message, "NEXORA · Subscription import", MessageBoxButton.OK, MessageBoxImage.Warning); }
        }

        private void ImportSubscriptionFile_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog { Title = "Import VPN configuration or subscription", Filter = "Supported configs|*.conf;*.ovpn;*.txt;*.json;*.yaml;*.yml|All files|*.*", Multiselect = true };
            if (dialog.ShowDialog(this) != true) return;
            foreach (string path in dialog.FileNames)
            {
                try
                {
                    var info = new FileInfo(path); if (info.Length > 2 * 1024 * 1024) throw new InvalidDataException("File exceeds 2 MB.");
                    string content = File.ReadAllText(path);
                    string id = Guid.NewGuid().ToString("N"); var parsed = _subscriptionParser.Parse(content, id);
                    var item = new SubscriptionItem { Id = id, Name = Path.GetFileNameWithoutExtension(path), Source = path, ImportType = "File", AddedAt = DateTime.Now, LastUpdated = DateTime.Now, NodeCount = parsed.Count };
                    _subscriptions.Add(item); foreach (var node in parsed) _nodes.Add(node);
                    SubscriptionStatus.Text = "Imported " + parsed.Count + " entries from " + Path.GetFileName(path) + ".";
                }
                catch (Exception ex) { SubscriptionStatus.Text = Path.GetFileName(path) + ": " + ex.Message; }
            }
            SaveSubscriptions(); if (_subscriptions.Count > 0) SubscriptionsList.SelectedIndex = _subscriptions.Count - 1;
        }

        private void SubscriptionsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = SubscriptionsList.SelectedItem as SubscriptionItem; if (selected == null || NodesList == null) return;
            NodesList.ItemsSource = _nodes.Where(n => n.SourceId == selected.Id).ToList();
            SubscriptionStatus.Text = selected.NodeCount + " entries · " + selected.ImportType + (selected.LastUpdated.HasValue ? " · updated " + selected.LastUpdated.Value.ToString("g") : "");
        }

        private void UpdateSubscription_Click(object sender, RoutedEventArgs e)
        {
            var selected = SubscriptionsList.SelectedItem as SubscriptionItem;
            if (selected == null) { SubscriptionStatus.Text = "Select a subscription first."; return; }
            if (selected.ImportType != "URL") { SubscriptionStatus.Text = "Local files cannot be refreshed from a URL."; return; }
            try
            {
                SubscriptionStatus.Text = "Updating " + selected.Name + "…";
                string content = _subscriptionParser.Fetch(selected.Source); var parsed = _subscriptionParser.Parse(content, selected.Id);
                for (int i = _nodes.Count - 1; i >= 0; i--) if (_nodes[i].SourceId == selected.Id) _nodes.RemoveAt(i);
                foreach (var node in parsed) _nodes.Add(node);
                selected.NodeCount = parsed.Count; selected.LastUpdated = DateTime.Now; selected.LastError = null;
                SaveSubscriptions(); SubscriptionsList.Items.Refresh(); NodesList.ItemsSource = _nodes.Where(n => n.SourceId == selected.Id).ToList();
                SubscriptionStatus.Text = "Updated · " + parsed.Count + " entries.";
                AddNotification("Subscription updated", selected.Name + " · " + parsed.Count + " nodes", "Subscriptions");
            }
            catch (Exception ex) { selected.LastError = ex.Message; _subscriptionStore.Save(_subscriptions); SubscriptionStatus.Text = "Update failed: " + ex.Message; }
        }

        private void RemoveSubscription_Click(object sender, RoutedEventArgs e)
        {
            var selected = SubscriptionsList.SelectedItem as SubscriptionItem; if (selected == null) return;
            if (MessageBox.Show(this, "Remove '" + selected.Name + "' and its imported entries?", "NEXORA", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            for (int i = _nodes.Count - 1; i >= 0; i--) if (_nodes[i].SourceId == selected.Id) _nodes.RemoveAt(i);
            _subscriptions.Remove(selected); SaveSubscriptions(); NodesList.ItemsSource = null; SubscriptionStatus.Text = "Subscription removed.";
        }
        private void SaveSubscriptions() { _subscriptionStore.Save(_subscriptions); _subscriptionStore.SaveNodes(_nodes); }

        private void OpenConnections_Click(object sender, RoutedEventArgs e) { Navigate("Connections"); }
        private void OpenNotifications_Click(object sender, RoutedEventArgs e) { Navigate("Notifications"); }

        private void AddNotification(string title, string message, string category)
        {
            _notifications.Insert(0, new NotificationItem
            {
                Title = title,
                Message = message,
                Category = category,
                CreatedAt = DateTime.Now,
                IsRead = false
            });
            while (_notifications.Count > 100) _notifications.RemoveAt(_notifications.Count - 1);
            _notificationStore.Save(_notifications);
            UpdateNotificationHeader();
        }

        private void UpdateNotificationHeader()
        {
            if (NotificationButton == null) return;
            int unread = _notifications.Count(x => !x.IsRead);
            NotificationButton.Content = "Notifications · " + unread;
            NotificationSummary.Text = unread == 0
                ? _notifications.Count + " notifications · all caught up"
                : unread + " unread · " + _notifications.Count + " total";
        }

        private void NotificationsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = NotificationsList.SelectedItem as NotificationItem;
            if (selected == null || selected.IsRead) return;
            selected.IsRead = true;
            NotificationsList.Items.Refresh();
            _notificationStore.Save(_notifications);
            UpdateNotificationHeader();
        }

        private void MarkAllRead_Click(object sender, RoutedEventArgs e)
        {
            foreach (var item in _notifications) item.IsRead = true;
            NotificationsList.Items.Refresh();
            _notificationStore.Save(_notifications);
            UpdateNotificationHeader();
        }

        private void ClearNotifications_Click(object sender, RoutedEventArgs e)
        {
            _notifications.Clear();
            _notificationStore.Save(_notifications);
            UpdateNotificationHeader();
        }
        private void OpenTheme_Click(object sender, RoutedEventArgs e) { Navigate("Theme"); }
        private void OpenLayout_Click(object sender, RoutedEventArgs e) { Navigate("Layout"); }

        private void AddProfile_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new ProfileDialog { Owner = this };
            if (dialog.ShowDialog() == true)
            {
                _profiles.Add(new Profile { Name = dialog.ProfileName, Address = dialog.ProfileAddress });
                _profileStore.Save(_profiles);
                ProfilesList.SelectedIndex = _profiles.Count - 1;
                AddNotification("Profile added", "The profile '" + dialog.ProfileName + "' was saved locally.", "Profiles");
            }
        }

        private void ProfilesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var profile = ProfilesList.SelectedItem as Profile;
            if (profile != null)
            {
                ActiveProfileText.Text = profile.Name;
                PageSubtitle.Text = "Selected profile: " + profile.Name;
            }
        }

        private void AccentPicker_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (AccentPicker == null || AccentPicker.SelectedIndex < 0) return;
            Color[] colors =
            {
                Color.FromRgb(121, 183, 168),
                Color.FromRgb(112, 153, 181),
                Color.FromRgb(112, 169, 145),
                Color.FromRgb(180, 126, 139),
                Color.FromRgb(184, 157, 111)
            };
            ThemeService.SetAccent(colors[Math.Min(AccentPicker.SelectedIndex, colors.Length - 1)]);
        }

        private void OpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (OpacitySlider != null) ThemeService.SetPanelOpacity(OpacitySlider.Value);
        }

        private void LayoutPreset_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button != null) LayoutMessage.Text = "Current preset: " + button.Content;
        }
    }

    internal sealed class ProfileDialog : Window
    {
        private readonly TextBox _name = new TextBox();
        private readonly TextBox _address = new TextBox();

        public string ProfileName { get { return _name.Text.Trim(); } }
        public string ProfileAddress { get { return _address.Text.Trim(); } }

        public ProfileDialog()
        {
            Title = "Add profile";
            Width = 420;
            Height = 270;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            Background = new SolidColorBrush(Color.FromRgb(25, 26, 39));
            Foreground = Brushes.White;
            var panel = new StackPanel { Margin = new Thickness(22) };

            panel.Children.Add(new TextBlock { Text = "Profile name", Margin = new Thickness(0, 0, 0, 5) });
            _name.Margin = new Thickness(0, 0, 0, 14);
            panel.Children.Add(_name);

            panel.Children.Add(new TextBlock { Text = "Server / configuration address", Margin = new Thickness(0, 0, 0, 5) });
            _address.Margin = new Thickness(0, 0, 0, 18);
            panel.Children.Add(_address);

            var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            var cancel = new Button { Content = "Cancel", Margin = new Thickness(0, 0, 8, 0), MinWidth = 85 };
            cancel.Click += (s, e) => { DialogResult = false; };
            var save = new Button { Content = "Save profile", MinWidth = 100, Background = new SolidColorBrush(Color.FromRgb(115, 96, 205)) };
            save.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(ProfileName))
                {
                    MessageBox.Show(this, "Enter a profile name.", "NEXORA", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                DialogResult = true;
            };
            buttons.Children.Add(cancel);
            buttons.Children.Add(save);
            panel.Children.Add(buttons);
            Content = panel;
        }
    }
}
