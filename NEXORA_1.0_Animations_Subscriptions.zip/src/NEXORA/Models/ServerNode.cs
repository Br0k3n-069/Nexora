using System;
using System.Runtime.Serialization;

namespace NEXORA.Models
{
    [DataContract]
    public sealed class ServerNode
    {
        [DataMember] public string Id { get; set; }
        [DataMember] public string Name { get; set; }
        [DataMember] public string Protocol { get; set; }
        [DataMember] public string Host { get; set; }
        [DataMember] public int Port { get; set; }
        [DataMember] public string SourceId { get; set; }
        [DataMember] public string RawConfiguration { get; set; }
        [DataMember] public DateTime ImportedAt { get; set; }
        public override string ToString() { return Name + "  ·  " + Protocol + "  ·  " + Host + (Port > 0 ? ":" + Port : ""); }
    }

    [DataContract]
    public sealed class SubscriptionItem
    {
        [DataMember] public string Id { get; set; }
        [DataMember] public string Name { get; set; }
        [DataMember] public string Source { get; set; }
        [DataMember] public string ImportType { get; set; }
        [DataMember] public DateTime AddedAt { get; set; }
        [DataMember] public DateTime? LastUpdated { get; set; }
        [DataMember] public int NodeCount { get; set; }
        [DataMember] public string LastError { get; set; }
    }
}
