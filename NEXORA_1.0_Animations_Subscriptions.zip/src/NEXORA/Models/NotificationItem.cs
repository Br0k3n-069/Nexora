using System;
using System.Runtime.Serialization;

namespace NEXORA.Models
{
    [DataContract]
    public class NotificationItem
    {
        [DataMember] public string Title { get; set; }
        [DataMember] public string Message { get; set; }
        [DataMember] public string Category { get; set; }
        [DataMember] public DateTime CreatedAt { get; set; }
        [DataMember] public bool IsRead { get; set; }

        public string TimeLabel { get { return CreatedAt.ToString("dd MMM yyyy, HH:mm"); } }
        public string ReadLabel { get { return IsRead ? "READ" : "NEW"; } }
    }
}
